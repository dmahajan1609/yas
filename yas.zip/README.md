# yas
A nodejs based alexa skills kit for a motivational tool to accomplish our life goals. Yas Queen, go out and get it! 

# Who are we ?
Lety Rojas
Clara Devers
Charletta Bullard
Divya Mahajan
Gina Mariani
